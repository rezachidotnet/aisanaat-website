"""python3 -m unittest — path safety, S3 config args, and a real upload/list/download/delete through rclone (local disk remote)."""
import json, os, shutil, tempfile, threading, unittest, urllib.request
from pathlib import Path
import server


class Pure(unittest.TestCase):
    def test_clean_blocks_escape(self):
        for bad in ('../x', 'a/../../b', '/etc/passwd', 'a\\b', 'a\x00b'):
            with self.assertRaises(server.Fail):
                server.clean(bad)
        self.assertEqual(server.clean('a//b/'), 'a/b')

    def test_join(self):
        self.assertEqual(server.join('gd:', 'a/b'), 'gd:a/b')
        self.assertEqual(server.join('anbar:bkt', 'a'), 'anbar:bkt/a')
        self.assertEqual(server.join('anbar:bkt', ''), 'anbar:bkt')

    def test_s3_args(self):
        a = server.s3_args({'provider': 'Other', 'endpoint': 'https://s3.x.ir/', 'access_key': ' K ', 'secret_key': 'S', 'bucket': 'b'})
        self.assertIn('endpoint=s3.x.ir', a)
        self.assertIn('access_key_id=K', a)
        with self.assertRaises(server.Fail):
            server.s3_args({'access_key': 'K', 'secret_key': '', 'bucket': 'b'})


class EndToEnd(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        server.CONF = self.tmp / 'conf.json'
        server.CONF.write_text(json.dumps({'remote': str(self.tmp / 'store')}))  # rclone treats a plain path as local disk
        (self.tmp / 'store').mkdir()
        self.srv = server.make_server(0)
        server.PORT = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.base = f'http://127.0.0.1:{server.PORT}'

    def tearDown(self):
        self.srv.shutdown(); shutil.rmtree(self.tmp)

    def call(self, path, data=None):
        req = urllib.request.Request(self.base + path, data=data, headers={'X-Anbar': '1'} if data is not None else {})
        try:
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    def test_upload_list_download_delete(self):
        blob = os.urandom(3 * server.CHUNK + 7)
        self.assertEqual(self.call('/api/upload?path=docs/x.bin', blob)[0], 200)
        self.assertEqual(self.call('/api/upload?path=docs/x.bin', b'new')[0], 409)  # no silent overwrite
        self.assertEqual(json.loads(self.call('/api/ls?path=docs')[1])['items'][0]['name'], 'x.bin')
        self.assertEqual(self.call('/api/file?path=docs/x.bin')[1], blob)
        self.assertEqual(self.call('/api/upload?path=docs/x.bin&overwrite=1', b'new')[0], 200)
        self.assertEqual(json.loads(self.call('/api/search?q=X.B')[1])['total'], 1)
        self.assertEqual(self.call('/api/delete', json.dumps({'path': 'docs/x.bin'}).encode())[0], 200)
        self.assertEqual(self.call('/api/file?path=docs/x.bin')[0], 404)

    def test_post_needs_header_and_escape_blocked(self):
        req = urllib.request.Request(self.base + '/api/delete', data=b'{}')
        with self.assertRaises(urllib.error.HTTPError) as e:
            urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req)
        self.assertEqual(e.exception.code, 403)
        self.assertEqual(self.call('/api/upload?path=../evil', b'x')[0], 400)




if __name__ == '__main__':
    unittest.main()

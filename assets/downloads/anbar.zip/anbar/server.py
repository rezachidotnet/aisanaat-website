"""«انبار» — a small local dashboard for your cloud storage (any rclone remote).

Run:  python server.py   → opens http://127.0.0.1:5572
Needs Python 3.9+ and rclone (https://rclone.org/downloads/). On Windows, rclone.exe can sit next to this file.
Nothing leaves your computer except the calls rclone makes to your own storage.
"""
import json
import os
import shutil
import subprocess
import sys
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath

DIR = Path(__file__).resolve().parent
PORT = int(os.environ.get('ANBAR_PORT', 5572))
CONF = Path.home() / '.anbar.json'
REMOTE_NAME = 'anbar'
STATIC = {'/': 'index.html', '/index.html': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/vazir-ar.woff2': 'vazir-ar.woff2', '/vazir-lat.woff2': 'vazir-lat.woff2'}
TYPES = {'.woff2': 'font/woff2', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8'}
RCLONE = str(DIR / 'rclone.exe') if (DIR / 'rclone.exe').exists() else 'rclone'
ENV = {**os.environ, 'RCLONE_CONTIMEOUT': '15s', 'RCLONE_TIMEOUT': '120s', 'RCLONE_RETRIES': '1', 'RCLONE_LOW_LEVEL_RETRIES': '2'}
CACHE: dict = {}
CHUNK = 1 << 20


class Fail(Exception):
    def __init__(self, code: int, msg: str):
        super().__init__(msg)
        self.code = code


def rclone(*args, input=None) -> bytes:
    try:
        r = subprocess.run([RCLONE, *args], input=input, capture_output=True, env=ENV, timeout=600)
    except FileNotFoundError:
        raise Fail(500, 'rclone پیدا نشد؛ مرحلهٔ ۱ راهنما را انجام دهید')
    except subprocess.TimeoutExpired:
        raise Fail(504, 'فضای ابری جواب نداد')
    if r.returncode in (3, 4):
        raise Fail(404, 'پیدا نشد')
    if r.returncode:
        raise Fail(502, explain(r.stderr.decode(errors='replace')))
    return r.stdout


def explain(err: str) -> str:
    """rclone's English stderr → one Farsi sentence the user can act on."""
    hints = (
        (('status code: 403', 'AccessDenied', 'InvalidAccessKeyId', 'SignatureDoesNotMatch', 'Forbidden'), 'کلید دسترسی (Access/Secret Key) اشتباه است یا به این باکت دسترسی ندارد'),
        (('NoSuchBucket', 'status code: 404'), 'باکتی با این نام پیدا نشد'),
        (('no such host', 'connection refused', 'i/o timeout', 'dial tcp', 'connection reset', 'TLS handshake'),
         'به سرور فضای ابری نرسیدیم؛ Endpoint را چک کنید. فضای ابری ایرانی (لیارا، آروان) با VPN روشن معمولاً وصل نمی‌شود'),
    )
    for keys, msg in hints:
        if any(k in err for k in keys):
            return msg
    last = err.strip().splitlines()[-1][-200:] if err.strip() else ''
    return 'خطای فضای ابری' + (': ' + last if last else '')


# ---------- config ----------
def config() -> dict:
    try:
        return json.loads(CONF.read_text())
    except (OSError, ValueError):
        return {}


def remote() -> str:
    r = config().get('remote')
    if not r:
        raise Fail(409, 'هنوز فضای ابری وصل نشده')
    return r


def clean(p: str) -> str:
    """'' or a relative path without .. — what the browser may ask for."""
    if '\x00' in p or p.startswith('/') or '\\' in p:
        raise Fail(400, 'مسیر نامعتبر')
    parts = PurePosixPath(p).parts if p else ()
    if '..' in parts:
        raise Fail(400, 'مسیر نامعتبر')
    return '/'.join(parts)


def join(root: str, p: str) -> str:
    p = clean(p)
    if not p:
        return root
    return root + p if root.endswith(':') else root.rstrip('/') + '/' + p


def s3_args(f: dict) -> list[str]:
    """`rclone config create` arguments for an S3-compatible storage (Liara, ArvanCloud, AWS, MinIO…)."""
    for k in ('access_key', 'secret_key', 'bucket'):
        if not str(f.get(k, '')).strip():
            raise Fail(400, 'همهٔ خانه‌ها را پر کنید')
    args = ['config', 'create', REMOTE_NAME, 's3', f"provider={f.get('provider') or 'Other'}",
            f"access_key_id={f['access_key'].strip()}", f"secret_access_key={f['secret_key'].strip()}", 'no_check_bucket=true']
    if f.get('endpoint', '').strip():
        args.append(f"endpoint={f['endpoint'].strip().removeprefix('https://').removeprefix('http://').rstrip('/')}")
    if f.get('region', '').strip():
        args.append(f"region={f['region'].strip()}")
    return args


def connect(f: dict) -> dict:
    if f.get('kind') == 'remote':  # a remote the user already made with `rclone config` (Google Drive, Dropbox, …)
        name = str(f.get('name', '')).rstrip(':')
        if name + ':' not in remotes()['remotes']:
            raise Fail(400, 'این ریموت در rclone نیست')
        target = name + ':' + clean(str(f.get('path', '')).strip('/'))
    else:
        rclone(*s3_args(f))
        target = f'{REMOTE_NAME}:' + clean(f['bucket'].strip().strip('/'))
    rclone('lsf', '--max-depth', '1', target)  # proves keys + bucket work before we save anything
    CONF.write_text(json.dumps({'remote': target}, ensure_ascii=False))
    CACHE.clear()
    return {'remote': target}


def remotes() -> dict:
    try:
        out = rclone('listremotes').decode().split()
    except Fail:
        out = []
    return {'remotes': out, 'rclone': bool(shutil.which(RCLONE)), 'remote': config().get('remote', '')}


# ---------- files ----------
def ls(path: str) -> dict:
    items = json.loads(rclone('lsjson', '--no-mimetype', join(remote(), path)))
    return {'path': clean(path), 'items': sorted(({'name': i['Name'], 'dir': i['IsDir'], 'size': i['Size'], 'modified': i['ModTime']} for i in items),
                                                  key=lambda i: (not i['dir'], i['name'].lower()))}


def search(q: str, refresh=False) -> dict:
    if refresh or 'all' not in CACHE:
        CACHE['all'] = json.loads(rclone('lsjson', '-R', '--files-only', '--fast-list', '--no-mimetype', remote()))
    q = q.strip().lower()
    hits = [{'path': f['Path'], 'size': f['Size'], 'modified': f['ModTime']} for f in CACHE['all'] if q and q in f['Path'].lower()]
    hits.sort(key=lambda f: f['modified'], reverse=True)
    return {'hits': hits[:300], 'total': len(hits)}


def exists(path: str) -> bool:
    try:
        return bool(json.loads(rclone('lsjson', '--files-only', join(remote(), path))))
    except Fail as e:
        if e.code == 404:
            return False
        raise


def delete(path: str) -> dict:
    if not clean(path):
        raise Fail(400, 'مسیر نامعتبر')
    rclone('deletefile', join(remote(), path))
    CACHE.pop('all', None)
    return {'ok': True}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body: bytes, ctype='application/json; charset=utf-8', extra=None):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def json(self, code, obj):
        self.send(code, json.dumps(obj, ensure_ascii=False).encode())

    def guard(self) -> bool:
        # only this computer's browser, and only from our own page (blocks other websites poking the API)
        if self.headers.get('Host') not in (f'127.0.0.1:{PORT}', f'localhost:{PORT}') or \
           (self.command == 'POST' and self.headers.get('X-Anbar') != '1'):
            self.json(403, {'error': 'دسترسی مجاز نیست'})
            return False
        return True

    def run(self, fn):
        try:
            self.json(200, fn())
        except Fail as e:
            self.json(e.code, {'error': str(e)})
        except (ValueError, KeyError, TypeError):
            self.json(400, {'error': 'درخواست نامعتبر'})

    def do_GET(self):
        if not self.guard():
            return
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        if u.path in STATIC:
            f = DIR / STATIC[u.path]
            return self.send(200, f.read_bytes(), TYPES[f.suffix])
        if u.path == '/api/file':
            return self.download(q.get('path', ''), q.get('inline') == '1')
        routes = {'/api/status': lambda: remotes(), '/api/ls': lambda: ls(q.get('path', '')),
                  '/api/search': lambda: search(q.get('q', ''), q.get('refresh') == '1')}
        if u.path not in routes:
            return self.json(404, {'error': 'پیدا نشد'})
        self.run(routes[u.path])

    def do_POST(self):
        if not self.guard():
            return
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        if u.path == '/api/upload':
            return self.run(lambda: self.upload(q.get('path', ''), q.get('overwrite') == '1'))
        body = self.rfile.read(int(self.headers.get('Content-Length') or 0))
        routes = {'/api/connect': lambda: connect(json.loads(body)), '/api/delete': lambda: delete(json.loads(body)['path']),
                  '/api/disconnect': lambda: (CONF.unlink(missing_ok=True), CACHE.clear(), {'ok': True})[-1]}
        if u.path not in routes:
            return self.json(404, {'error': 'پیدا نشد'})
        self.run(routes[u.path])

    def upload(self, path: str, overwrite: bool) -> dict:
        # streamed straight into `rclone rcat`, so a 5 GB video never sits in memory or on disk twice
        n = int(self.headers.get('Content-Length') or 0)
        if not clean(path) or path.endswith('/'):
            raise Fail(400, 'مسیر نامعتبر')
        if not overwrite and exists(path):
            self.rfile.read(n)
            raise Fail(409, 'فایلی با همین نام هست')
        p = subprocess.Popen([RCLONE, 'rcat', '--size', str(n), join(remote(), path)], stdin=subprocess.PIPE,
                             stderr=subprocess.PIPE, env=ENV)
        try:
            while n > 0:
                chunk = self.rfile.read(min(CHUNK, n))
                if not chunk:
                    break
                p.stdin.write(chunk)
                n -= len(chunk)
            p.stdin.close()
        except BrokenPipeError:
            pass
        err = p.stderr.read().decode(errors='replace')
        if p.wait() or n:
            raise Fail(502, 'آپلود ناموفق بود: ' + explain(err))
        CACHE.pop('all', None)
        return {'path': clean(path)}

    def download(self, path: str, inline: bool):
        try:
            target = join(remote(), path)
            if not clean(path):
                raise Fail(400, 'مسیر نامعتبر')
        except Fail as e:
            return self.json(e.code, {'error': str(e)})
        p = subprocess.Popen([RCLONE, 'cat', target], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=ENV)
        first = p.stdout.read(CHUNK)
        if not first and p.wait():
            return self.json(404, {'error': 'پیدا نشد'})
        name = path.rsplit('/', 1)[-1]
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Disposition', f"{'inline' if inline else 'attachment'}; filename*=UTF-8''{urllib.parse.quote(name)}")
        self.end_headers()
        try:
            while first:
                self.wfile.write(first)
                first = p.stdout.read(CHUNK)
        except (BrokenPipeError, ConnectionResetError):
            p.kill()
        p.wait()


def make_server(port: int = PORT) -> ThreadingHTTPServer:
    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


if __name__ == '__main__':
    url = f'http://127.0.0.1:{PORT}'
    print(f'«انبار» روی {url} باز است. برای بستن Ctrl+C بزنید.')
    if '--no-browser' not in sys.argv:
        webbrowser.open(url)
    try:
        make_server().serve_forever()
    except KeyboardInterrupt:
        pass

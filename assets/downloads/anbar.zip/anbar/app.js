// «انبار» — UI for server.py. Views: #/setup (connect wizard), #/d/<folder> (files), #/search?q=
const $ = s => document.querySelector(s);
const fa = n => Number(n).toLocaleString('fa-IR');
const EXT = { pdf: 'pdf', md: 'md', html: 'html', mp4: 'vid', mov: 'vid', mkv: 'vid', webm: 'vid', png: 'img', jpg: 'img', jpeg: 'img', svg: 'img', webp: 'img', pptx: 'deck', key: 'deck' };
const PRESETS = {
  liara: { label: 'لیارا', provider: 'Other', endpoint: 'storage.iran.liara.site',
    help: ['در پنل لیارا به بخش «ذخیره‌سازی ابری» بروید و یک باکت بسازید.', 'در تنظیمات همان باکت، یک کلید دسترسی (Access Key و Secret Key) بسازید.', 'آدرس Endpoint در صفحهٔ باکت نوشته شده؛ اگر با پیش‌فرض این فرم فرق دارد، عوضش کنید.'] },
  arvan: { label: 'آروان‌کلاد', provider: 'Other', endpoint: 's3.ir-thr-at1.arvanstorage.ir',
    help: ['در پنل آروان‌کلاد به «فضای ابری» بروید و یک باکت بسازید.', 'از بخش «کلیدهای دسترسی» یک Access Key و Secret Key بگیرید.', 'Endpoint منطقهٔ باکت را از صفحهٔ باکت بردارید (پیش‌فرض: تهران).'] },
  aws: { label: 'Amazon S3', provider: 'AWS', endpoint: '', region: 'us-east-1',
    help: ['در کنسول AWS یک باکت S3 بسازید و منطقه (Region) آن را یادداشت کنید.', 'در IAM یک کاربر با دسترسی به همان باکت بسازید و Access Key بگیرید.'] },
  other: { label: 'S3 دیگر (MinIO، پارس‌پک، …)', provider: 'Other', endpoint: '',
    help: ['هر سرویسی که «سازگار با S3» است کار می‌کند.', 'از پنلش Endpoint، Access Key، Secret Key و نام باکت را بردارید.'] },
};
const S = { status: null, preset: 'liara' };

function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(Infinity)) if (c != null && c !== false) el.append(c.nodeType ? c : String(c));
  return el;
}
function toast(msg, err = false) { const t = h('div', { class: err ? 'err' : null }, msg); $('#toast').append(t); setTimeout(() => t.remove(), err ? 7000 : 3500); }
async function api(path, body) {
  const r = await fetch(path, body === undefined ? {} : { method: 'POST', headers: { 'X-Anbar': '1' }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'خطا'), { code: r.status });
  return d;
}
const size = b => b < 1024 ? fa(b) + ' B' : b < 1048576 ? fa((b / 1024).toFixed(0)) + ' KB' : b < 1073741824 ? fa((b / 1048576).toFixed(1)) + ' MB' : fa((b / 1073741824).toFixed(1)) + ' GB';
const date = iso => new Date(iso).toLocaleDateString('fa-IR', { year: 'numeric', month: 'short', day: 'numeric' });
const extOf = n => (n.includes('.') ? n.split('.').pop().toLowerCase() : '');
const badge = n => { const e = extOf(n); return h('span', { class: 'ext ' + (EXT[e] || '') }, (e || '—').slice(0, 4).toUpperCase()); };
const fileUrl = (p, inline) => '/api/file?path=' + encodeURIComponent(p) + (inline ? '&inline=1' : '');
const dirHash = p => '#/d/' + p.split('/').map(encodeURIComponent).join('/');
const here = () => location.hash.startsWith('#/d/') ? location.hash.slice(4).split('/').map(decodeURIComponent).filter(Boolean).join('/') : '';

// ---------- setup wizard ----------
function setup() {
  const st = S.status, p = PRESETS[S.preset];
  const field = (name, label, value = '', type = 'text') => h('label', {}, label, h('input', { name, value, type, required: true, autocomplete: 'off', spellcheck: 'false' }));
  const form = h('form', { class: 'form', onsubmit: connect },
    h('input', { type: 'hidden', name: 'provider', value: p.provider }),
    p.provider === 'AWS' ? field('region', 'Region', p.region) : field('endpoint', 'Endpoint (آدرس سرور)', p.endpoint),
    field('bucket', 'نام باکت (Bucket)'), field('access_key', 'Access Key'), field('secret_key', 'Secret Key', '', 'password'),
    h('button', { class: 'btn', type: 'submit' }, 'اتصال و آزمایش'));
  const remotes = st.remotes.filter(r => r !== 'anbar:');
  return h('div', { class: 'screen' },
    h('h2', {}, 'اتصال فضای ابری به انبار'),
    st.remote ? h('p', { class: 'ok' }, '✓ وصل است به ', h('span', { class: 'ltr' }, st.remote), ' · ', h('a', { href: '#/' }, 'رفتن به فایل‌ها ←')) : h('p', { class: 'meta' }, 'چهار قدم کوتاه؛ یک بار انجامش می‌دهید.'),
    h('div', { class: 'steps', style: 'margin-top:14px' },
      h('div', { class: 'step' }, h('h4', {}, 'نصب rclone ', st.rclone ? h('span', { class: 'ok' }, '✓ نصب است') : null),
        h('p', {}, 'انبار با ابزار رایگان rclone با فضای ابری حرف می‌زند.'),
        h('ul', {}, h('li', {}, 'ویندوز: فایل zip را از ', h('a', { class: 'ltr', href: 'https://rclone.org/downloads/', target: '_blank', rel: 'noopener' }, 'rclone.org/downloads'), ' بگیرید و ', h('code', {}, 'rclone.exe'), ' را کنار ', h('code', {}, 'server.py'), ' بگذارید.'),
          h('li', {}, 'مک: ', h('code', {}, 'brew install rclone'), ' · لینوکس: ', h('code', {}, 'sudo apt install rclone')),
          h('li', {}, 'بعد از نصب، این صفحه را دوباره باز کنید (', h('code', {}, 'python server.py'), ').'))),
      h('div', { class: 'step' }, h('h4', {}, 'ساخت باکت و کلید در پنل فضای ابری'),
        h('div', { class: 'tabs' }, Object.entries(PRESETS).map(([k, v]) => h('button', { class: 'chip' + (k === S.preset ? ' on' : ''), type: 'button', onclick: () => { S.preset = k; route(); } }, v.label))),
        h('ol', {}, p.help.map(t => h('li', {}, t)))),
      h('div', { class: 'step' }, h('h4', {}, 'وارد کردن مشخصات'),
        h('p', {}, 'کلیدها فقط روی همین کامپیوتر، در تنظیمات rclone، ذخیره می‌شوند.'), form),
      h('div', { class: 'step' }, h('h4', {}, 'تمام!'),
        h('p', {}, 'بعد از «اتصال و آزمایش»، انبار یک بار فهرست باکت را می‌خواند و اگر درست بود شما را به فایل‌ها می‌برد. حالا با دکمهٔ «آپلود فایل» هر فایلی از دستگاهتان را به فضای ابری بفرستید.')),
      h('details', { class: 'step' }, h('summary', {}, 'گوگل درایو، Dropbox، OneDrive یا ریموتی که قبلاً ساخته‌اید'),
        h('p', {}, 'در ترمینال ', h('code', {}, 'rclone config'), ' را اجرا کنید و طبق سؤال‌ها یک ریموت بسازید (برای گوگل درایو مرورگر باز می‌شود تا اجازه بدهید). بعد اینجا انتخابش کنید:'),
        remotes.length ? h('form', { class: 'form', onsubmit: e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); doConnect({ kind: 'remote', ...f }, e.target); } },
          h('label', {}, 'ریموت', h('select', { name: 'name' }, remotes.map(r => h('option', { value: r }, r)))),
          h('label', {}, 'پوشه (اختیاری)', h('input', { name: 'path', placeholder: 'anbar' })),
          h('button', { class: 'btn', type: 'submit' }, 'اتصال و آزمایش'))
          : h('p', { class: 'meta' }, 'هنوز ریموتی در rclone نیست.'))),
    st.remote ? h('button', { class: 'btn ghost', style: 'margin-top:14px', onclick: async () => { await api('/api/disconnect', {}); await refreshStatus(); route(); } }, 'قطع اتصال') : null);
}

function connect(e) { e.preventDefault(); doConnect(Object.fromEntries(new FormData(e.target)), e.target); }
async function doConnect(body, form) {
  const btn = form.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = 'در حال آزمایش…';
  try { const r = await api('/api/connect', body); toast('وصل شد: ' + r.remote); await refreshStatus(); location.hash = '#/'; }
  catch (e) { toast(e.message, true); btn.disabled = false; btn.textContent = 'اتصال و آزمایش'; }
}

// ---------- files ----------
async function folder(path) {
  const v = $('#view');
  v.replaceChildren(h('p', { class: 'empty' }, 'در حال خواندن…'));
  let items;
  try { items = (await api('/api/ls?path=' + encodeURIComponent(path))).items; }
  catch (e) { if (e.code !== 404) return v.replaceChildren(h('p', { class: 'empty' }, e.message)); items = []; } // a new, still-empty folder
  const parts = path ? path.split('/') : [];
  const drop = h('div', { class: 'drop', onclick: () => $('#pick').click() }, 'فایل‌ها را اینجا رها کنید یا بزنید تا از دستگاهتان انتخاب کنید');
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); upload([...e.dataTransfer.files]); };
  v.replaceChildren(h('div', { class: 'screen' },
    h('div', { class: 'crumb' }, h('a', { href: '#/' }, 'انبار'), parts.map((p, i) => [' › ', h('a', { href: dirHash(parts.slice(0, i + 1).join('/')), class: 'ltr', style: 'background:none;border:0' }, p)])),
    h('div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap' }, h('h2', { style: 'flex:1' }, parts.at(-1) || 'همهٔ فایل‌ها'),
      h('button', { class: 'btn ghost', onclick: newFolder }, '＋ پوشهٔ جدید')),
    items.length ? items.map(row) : h('p', { class: 'empty' }, 'این پوشه خالی است.'),
    h('div', { id: 'uploads' }), drop));
}

function row(it) {
  const full = (here() ? here() + '/' : '') + it.name;
  if (it.dir) return h('div', { class: 'row' }, h('span', { class: 'ext' }, '📁'), h('a', { class: 'f dir', href: dirHash(full) }, it.name + '/'));
  return h('div', { class: 'row' }, badge(it.name),
    h('a', { class: 'f', href: fileUrl(full, true), target: '_blank', rel: 'noopener' }, it.name),
    h('small', {}, size(it.size)), h('small', {}, date(it.modified)),
    h('a', { class: 'x', href: fileUrl(full), title: 'دانلود', 'aria-label': 'دانلود ' + it.name }, '⬇'),
    h('button', { class: 'x', title: 'حذف', 'aria-label': 'حذف ' + it.name, onclick: e => del(full, e.currentTarget) }, '🗑'));
}

async function del(path, btn) {
  if (btn.dataset.armed !== '1') { btn.dataset.armed = '1'; btn.textContent = 'حذف؟'; setTimeout(() => { btn.dataset.armed = ''; btn.textContent = '🗑'; }, 3000); return; }
  try { await api('/api/delete', { path }); toast(`«${path.split('/').pop()}» حذف شد`); route(); } catch (e) { toast(e.message, true); }
}

function newFolder() {
  const name = (prompt('نام پوشهٔ جدید:') || '').trim().replace(/[\\/]/g, '-');
  if (name) { location.hash = dirHash((here() ? here() + '/' : '') + name); toast('پوشه بعد از اولین آپلود ساخته می‌شود'); }
}

function send(path, file, overwrite, bar) { // XHR, not fetch: fetch has no upload progress
  return new Promise((ok, fail) => {
    const x = new XMLHttpRequest();
    x.open('POST', '/api/upload?path=' + encodeURIComponent(path) + (overwrite ? '&overwrite=1' : ''));
    x.setRequestHeader('X-Anbar', '1');
    x.upload.onprogress = e => { bar.style.width = (e.loaded / e.total * 100) + '%'; };
    x.onload = () => { let d = {}; try { d = JSON.parse(x.responseText); } catch {} x.status === 200 ? ok(d) : fail(Object.assign(new Error(d.error || 'خطا'), { code: x.status })); };
    x.onerror = () => fail(new Error('ارتباط با انبار قطع شد'));
    x.send(file);
  });
}

async function upload(files) {
  if (!S.status?.remote) return (location.hash = '#/setup');
  const dir = here(), box = $('#uploads');
  for (const f of files) {
    const path = (dir ? dir + '/' : '') + f.name, bar = h('i');
    const line = h('div', { class: 'row' }, badge(f.name), h('span', { class: 'f' }, f.name, h('div', { class: 'progress' }, bar)), h('small', {}, size(f.size)));
    box?.append(line);
    try {
      try { await send(path, f, false, bar); }
      catch (e) { if (e.code !== 409 || !confirm(`«${f.name}» از قبل هست. جایگزین شود؟`)) throw e; await send(path, f, true, bar); }
      toast(`«${f.name}» آپلود شد`);
    } catch (e) { toast(`«${f.name}»: ${e.message}`, true); }
    line.remove();
  }
  route();
}

async function search(q) {
  const v = $('#view'); $('#q').value = q;
  v.replaceChildren(h('p', { class: 'empty' }, 'در حال جستجو… (بار اول کمی طول می‌کشد)'));
  try {
    const { hits, total } = await api('/api/search?q=' + encodeURIComponent(q));
    v.replaceChildren(h('div', { class: 'screen' }, h('h2', {}, `${fa(total)} نتیجه`),
      hits.map(f => h('div', { class: 'row' }, badge(f.path),
        h('a', { class: 'f', href: fileUrl(f.path, true), target: '_blank', rel: 'noopener' }, f.path),
        h('small', {}, size(f.size)), h('small', {}, date(f.modified)),
        h('a', { class: 'x', href: dirHash(f.path.split('/').slice(0, -1).join('/')), title: 'باز کردن پوشه' }, '📁'))),
      total > hits.length ? h('p', { class: 'empty' }, 'فقط ۳۰۰ نتیجهٔ جدیدتر نمایش داده شد.') : null));
  } catch (e) { v.replaceChildren(h('p', { class: 'empty' }, e.message)); }
}

// ---------- routing ----------
async function refreshStatus() { S.status = await api('/api/status'); }
function route() {
  const [path, query] = location.hash.slice(1).split('?');
  if (path === '/setup' || !S.status.remote) return $('#view').replaceChildren(setup());
  if (path === '/search') return search(new URLSearchParams(query).get('q') || '');
  $('#q').value = '';
  folder(here());
}

let typing;
$('#q').addEventListener('input', e => { clearTimeout(typing); typing = setTimeout(() => { const q = e.target.value.trim(); location.hash = q ? '#/search?' + new URLSearchParams({ q }) : '#/'; }, 300); });
$('#up').onclick = () => $('#pick').click();
$('#pick').onchange = e => { upload([...e.target.files]); e.target.value = ''; };
addEventListener('hashchange', route);
refreshStatus().then(route).catch(e => $('#view').replaceChildren(h('p', { class: 'empty' }, e.message)));
